   Assignment  made using sublime text editor
===================================================



Assignment 2
------------



# ← index.html

 the content of the website is present here. Website is divided into 3 sections namely Home, about, and contact.It also contain links to other websites like iiit.ac.in and some local html pages.


# ← page2.html : local html page linked with the index page.
	

# ← style.css

CSS files add styling rules to your content. Mostly this file is used to style the webpage.

# ← script.js

Using jquery done to show some effect of blinking and dropdown in page2.html


-------------------


